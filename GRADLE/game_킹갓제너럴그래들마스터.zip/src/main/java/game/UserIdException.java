package game;

/**
 * Handle errors when user login.
 */
public class UserIdException extends IllegalArgumentException {
    public UserIdException(String s) {
        super(s);
    }

    public UserIdException() {
    }
}
