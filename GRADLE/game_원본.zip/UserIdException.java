package game;

public class UserIdException extends IllegalArgumentException {
    public UserIdException(String s) {
        super(s);
    }

    public UserIdException() {
    }
}
