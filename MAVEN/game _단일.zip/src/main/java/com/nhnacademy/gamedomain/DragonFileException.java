package com.nhnacademy.gamedomain;

import java.io.IOException;

/**
 * Handle errors when loading dragon txt files.
 */
public class DragonFileException extends IOException {
    public DragonFileException() {
    }


    public DragonFileException(String message) {
        super(message);
    }
}
