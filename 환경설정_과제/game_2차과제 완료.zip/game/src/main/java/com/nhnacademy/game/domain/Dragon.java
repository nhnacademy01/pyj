package com.nhnacademy.game.domain;

import java.util.Objects;

/**
 * com.nhnacademy.game.domain.Dragon class that inherits monsters.
 */
public class Dragon extends Character implements Monster {
    private static final String BASIC_ID = "드래곤";
    private static final String BASIC_STATE = "*보스* ";
    private static final int BASIC_LEVEL = 3;
    private static final int BASIC_HP = 100;
    private static final int ATTACK_GAGE = 10;

    private int hp = BASIC_HP;

    @Override
    public String getId() {
        return BASIC_ID;
    }

    @Override
    public String getState() {
        return BASIC_STATE;
    }

    @Override
    public int getLevel() {
        return BASIC_LEVEL;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }


    @Override
    public int attack() {
        if (randoms.nextInt(10) == 0) {
            return breath();
        }
        return (randoms.nextInt(ATTACK_GAGE) + 1);
    }

    public int breath() {
        return (15);
    }

    @Override
    public int attacked(int attackGage) {
        setHp((this.hp - attackGage));
        return (this.hp - attackGage);
    }

    @Override
    public String toString() {
        return "com.nhnacademy.game.domain.Dragon{" + "hp=" + hp + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Dragon dragon = (Dragon) o;
        return hp == dragon.hp;
    }

    @Override
    public int hashCode() {
        return Objects.hash(hp);
    }
}
