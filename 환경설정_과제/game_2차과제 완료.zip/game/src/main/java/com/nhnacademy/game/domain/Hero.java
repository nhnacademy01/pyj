package com.nhnacademy.game.domain;

import java.util.Objects;

/**
 * Classify com.nhnacademy.game.domain.Hero behavior.
 */
public class Hero extends Character {

    private static final int BASIC_HP = 100;
    private static final int BASIC_LEVEL = 1;
    private static final int BASIC_ATTACK_GAGE = 10;

    private String id;
    private int level = BASIC_LEVEL;
    private int hp = BASIC_HP;
    private int attackGage = BASIC_ATTACK_GAGE;


    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Override
    public String getState() {
        return null;
    }

    public int getLevel() {
        return level;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getAttackGage() {
        return attackGage;
    }

    public int attack() {
        return randoms.nextInt(attackGage) + 1;
    }

    @Override
    public int attacked(int attackGage) {
        setHp((this.hp - attackGage));
        return getHp();
    }

    /**
     * Make hero level Up.
     */
    public void levelUp() {
        this.hp = (getHp() + 5);
        this.level = (getLevel() + 1);
        this.attackGage = (getAttackGage() + 5);
    }

    @Override
    public String toString() {
        return "com.nhnacademy.game.domain.Hero{" + "id='" + id + '\'' + ", level=" + level + ", hp=" + hp + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Hero hero = (Hero) o;
        return level == hero.level && hp == hero.hp && attackGage == hero.attackGage &&
            Objects.equals(id, hero.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, level, hp, attackGage);
    }
}

