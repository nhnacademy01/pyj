package com.nhnacademy.game.domain;

/**
 * Classify com.nhnacademy.game.domain.Monster(com.nhnacademy.game.domain.Slime, com.nhnacademy.game.domain.Orc, com.nhnacademy.game.domain.Dragon) behavior.
 */
public interface Monster {
    public String getId();

    public int getLevel();

    public int getHp();

    public int attack();

    public int attacked(int attackGage);
}

