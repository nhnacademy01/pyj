package com.nhnacademy.game.domain;

/**
 * Handle errors when user login.
 */
public class UserIdException extends IllegalArgumentException {
    public UserIdException(String s) {
        super(s);
    }

    public UserIdException() {
    }
}
