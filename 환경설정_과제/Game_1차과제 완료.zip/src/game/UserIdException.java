package game;

/**
 * Handle errors when user trying login.
 */
public class UserIdException extends IllegalArgumentException {
    public UserIdException(String s) {
        super(s);
    }

    public UserIdException() {
    }
}
