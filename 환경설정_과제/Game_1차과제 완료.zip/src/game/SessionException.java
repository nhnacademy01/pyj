package game;

/**
 * Handle errors when session connected.
 */
public class SessionException extends IllegalArgumentException {
    public SessionException(String s) {
        super(s);
    }

    public SessionException() {
    }
}
