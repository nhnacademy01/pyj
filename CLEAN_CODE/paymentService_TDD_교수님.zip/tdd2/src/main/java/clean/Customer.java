package clean;

public class Customer {
}
