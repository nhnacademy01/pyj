package com.nhnacademy.myeongjujung.tdd.mockito;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class AccountServiceMockTest {
    private AccountService service;
    private AccountRepository repository;
    private Account account;

    @BeforeEach
    void setUp() {
        repository = mock(AccountRepository.class);
        service = new AccountService(repository);
    }

    @Test
    void login() {
        String username = "jordan";
        String password = "P@s5w0rd";

        Account account = new Account(username, password);
        when(repository.findByUsername(username)).thenReturn(account);

        Account result = service.login(username, password);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isNotNull().isPositive();
        assertThat(result.getUsername()).isEqualTo(username);
        assertThat(result.getPassword()).isEqualTo(password);

        verify(repository).findByUsername(username);    // !! verify(mock)
    }

    @Test
    void login_usernameIsNull_throwIllegalArgumentException() {
        String username = null;
        String password = "P@s5w0rd";

        //        Account account = new Account(username, password);
        //        when(repository.findByUsername(username)).thenReturn(account);

        assertThatIllegalArgumentException().isThrownBy(() -> service.login(username, password))
                                            .withMessageContaining("null");

        verify(repository, never()).findByUsername(any());  // !! verify never
    }


    @DisplayName("한 계정에 대해서 비밀번호를 연속 3번 틀리면 계정이 잠기게 해주세요.")
    @Test
    void login_incorrectPassword3Times_lockAccount() {
        String username = "jordan";
        String password = "invalid.password";

        account = new Account(username, "valid.password");
        when(repository.findByUsername(username)).thenReturn(account);

        failLogin(username, password);
        failLogin(username, password);
        failLogin(username, password);

        assertThat(account.isLock()).isTrue();

        verify(repository, times(3)).findByUsername(username);
    }

    @SuppressWarnings("CatchMayIgnoreException")
    private void failLogin(String username, String password) {
        try {
            service.login(username, password);
        } catch (LoginFailedException cause) {
        }
    }

    @DisplayName("계정이 잠기면 로그인할 수 없습니다.(`AccountLockedException` 예외가 발생합니다.)")
    @Test
    void login_accountIsLock_disabledLoginByAccountLockedException() {
        login_incorrectPassword3Times_lockAccount();

        String username = "jordan";
        String password = "invalid.password";

        assertThatThrownBy(() -> service.login(username, password))
                .isInstanceOf(AccountLockedException.class)
                .hasMessageContainingAll("lock", username);

        verify(repository, times(4)).findByUsername(username);
    }

    @DisplayName("비밀번호를 2번 틀리고, 3번째에 인증을 성공하면 비밀번호 틀림 패널티 횟수는 0으로 초기화 됩니다.")
    @Test
    void login_incorrectPassword2TimesAndTryLogin_initLoginFailCount() {
        String username = "jordan";
        String password = "invalid.password";

        account = new Account(username, "valid.password");
        when(repository.findByUsername(username)).thenReturn(account);

        failLogin(username, password);
        failLogin(username, password);
        Account result = service.login(username, account.getPassword());
        assertThat(result.getLoginFailCount()).isEqualTo(0);

        verify(repository, times(3)).findByUsername(username);
    }

    @DisplayName("잠긴 계정을 풀 수 있습니다")
    @Test
    void unlock() {
        Account account = new Account("jordan", "P@s5w0rd");
        Long accountId = account.getId();

        when(repository.findById(accountId)).thenReturn(account);

        service.unlock(accountId);

        assertThat(account.isLock()).isFalse();

        verify(repository).findById(accountId);
    }

}
















