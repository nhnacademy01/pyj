package com.nhnacademy.myeongjujung.tdd.mockito;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AccountServiceFakeTest {
    private AccountService service;
    private AccountRepository repository;
    private Account account;

    @BeforeEach
    void setUp() {
        repository = new HashMapAccountRepository();
        service = new AccountService(repository);

        account = new Account("jordan", "P@s5w0rd");
    }

    @Test
    void join() {
        service.join(account);
    }
}