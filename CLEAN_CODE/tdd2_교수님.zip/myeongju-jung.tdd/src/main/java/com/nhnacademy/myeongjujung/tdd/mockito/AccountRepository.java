package com.nhnacademy.myeongjujung.tdd.mockito;

public interface AccountRepository {
    void insert(Account account);

    Account findByUsername(String username);

    Account findById(Long accountId);
}
