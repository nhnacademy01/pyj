package com.nhnacademy.myeongjujung.tdd;

public class StringUtils {
    public static boolean isPalindrome(String candidate) {
        // TODO
        return false;
    }
}
