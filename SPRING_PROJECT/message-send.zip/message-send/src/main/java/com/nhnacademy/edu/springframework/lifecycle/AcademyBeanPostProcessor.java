package com.nhnacademy.edu.springframework.lifecycle;

import org.springframework.beans.factory.config.BeanPostProcessor;

public class AcademyBeanPostProcessor implements BeanPostProcessor {
}
