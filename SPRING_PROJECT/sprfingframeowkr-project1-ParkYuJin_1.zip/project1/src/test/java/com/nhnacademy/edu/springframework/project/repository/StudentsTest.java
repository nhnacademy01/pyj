package com.nhnacademy.edu.springframework.project.repository;

import com.nhnacademy.edu.springframework.project.service.Student;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

@TestInstance(value = TestInstance.Lifecycle.PER_CLASS)
class StudentsTest {
    Students students = CsvStudents.getInstance();
    Collection<Student> expectedStudents = students.findAll();
    Scores csvScores = CsvScores.getInstance();

    @BeforeAll
    void setup(){
        students.load();
        csvScores.load();
    }

    @Test
    @DisplayName("student.csv 파일을 잘 읽어오는지 테스트 ")
    void load() {
        // 경로 틀렸을 때 에러 잘 나는지
//        assertThrows(IllegalStateException.class, () ->{
//            students.load();
//        });
    }

    @Test
    @DisplayName("student의 모든 객체를 잘 반환하는지")
    void findAll() {
        assertThat(students.findAll()).isNotNull();
        assertThat(students.findAll(), is(expectedStudents));
        assertThat(students.findAll().size(), is(expectedStudents.size()));

    }

    @Test
    @DisplayName("load 후 Students 안에 Score가 잘 들어오는지 ")
    void merge() {
//        students.findAll().stream().iterate(Students, n -> n+1)
//
//        assertThat(students.findAll().stream().filter(student -> student.getScore().getScore()).findFirst(), is(expectedStudents));
//        assertThat(students.findAll().size(), is(expectedStudents.size()));
    }
}