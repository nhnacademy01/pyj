package com.nhnacademy.edu.springframework.project.service;


import com.nhnacademy.edu.springframework.project.SpringMain;
import com.nhnacademy.edu.springframework.project.repository.CsvStudents;
import com.nhnacademy.edu.springframework.project.repository.Students;
import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
public class DefaultStudentService implements StudentService {
    private static final Log logger = LogFactory.getLog(DefaultStudentService.class);
    Students studentRepository = CsvStudents.getInstance();
    Map<Integer, Student> studentMap = studentRepository.getStudents();
    StopWatch stopWatch = new StopWatch();

    @Override
    public Collection<Student> getPassedStudents() {
        logger.info("DefaultStudentService getPassedStudents start");
        // DONE 1 : pass 한 학생만 반환하도록 수정하세요.
        try{
            stopWatch.start();
            Collection<Student> students = studentRepository.findAll();
            return students.stream()
                .filter(student -> student.getScore().getScore() >= 60)
                .collect(Collectors.toList());
        }finally {
            stopWatch.stop();
            logger.info("getPassedStudents : " + stopWatch.prettyPrint());
        }

    }

    @Override
    public Collection<Student> getStudentsOrderByScore() {
        logger.info("DefaultStudentService getStudentsOrderByScore start");
        // DONE 4 : 성적 순으로 학생 정보를 반환합니다.

        try{
            stopWatch.start();

            Collection<Student> students = studentRepository.findAll();
            return students.stream().sorted().collect(Collectors.toList());
        }finally {
            stopWatch.stop();
            logger.info("getStudentsOrderByScore : " + stopWatch.prettyPrint());
        }


    }
}

