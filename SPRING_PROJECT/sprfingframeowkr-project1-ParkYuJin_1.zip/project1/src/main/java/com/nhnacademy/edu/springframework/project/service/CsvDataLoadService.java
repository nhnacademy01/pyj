package com.nhnacademy.edu.springframework.project.service;

import com.nhnacademy.edu.springframework.project.SpringMain;
import com.nhnacademy.edu.springframework.project.repository.CsvScores;
import com.nhnacademy.edu.springframework.project.repository.CsvStudents;
import com.nhnacademy.edu.springframework.project.repository.Scores;
import com.nhnacademy.edu.springframework.project.repository.Students;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

public class CsvDataLoadService implements DataLoadService {
    private static final Log logger = LogFactory.getLog(DefaultStudentService.class);
    StopWatch stopWatch = new StopWatch();

    public void loadAndMerge() {
        logger.info("CsvDataLoadService loadAndMessage start");

        try {
            stopWatch.start();
            Scores scores = CsvScores.getInstance();
            scores.load();

            Students students = CsvStudents.getInstance();
            students.load();
            students.merge(scores.findAll());
        } finally {
            stopWatch.stop();
            logger.info("loadAndMerge : " + stopWatch.prettyPrint());

        }

    }
}
